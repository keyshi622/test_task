﻿
using System.Text;
using System.Xml.Linq;
using Microsoft.Data.Sqlite;

internal class Programm
{
    private static readonly HttpClient client = new HttpClient();
    private static readonly string LogFile = "log.txt";
    private static void Main(string[] args)
    {
        string connectionString = "Data Source=test.db";
        string xmlFile = "Orders.xml";
        string soapUrl = "http://localhost:8088/mockservice"; // адрес SOAP сервиса 
        string soapAction = "http://tempuri.org/SendOrders"; // SOAP Action

        using (var connection = new SqliteConnection(connectionString))
        {
            connection.Open();

            Log("=== Программа запущена ===");
            Log("Нажмите CTRL + C, чтобы остановить программу.\n");

            while (true)
            {
                try
                {
                    UpdateOrdersXml(connection, xmlFile);
                    Log("XML обновлён.");

                    SendXmlToSoap(xmlFile, soapUrl, soapAction).Wait();
                }
                catch (Exception ex)
                {
                    Log($"Ошибка: {ex.Message}", isError: true);
                }

                Thread.Sleep(TimeSpan.FromMinutes(1));
            }
        }
    }

    private static void UpdateOrdersXml(SqliteConnection connection, string xmlFile)
    {
        try
        {
            var select = connection.CreateCommand();
            select.CommandText = "SELECT Id, OrderNumber, Amount, CreatedAt FROM Orders;";

            var ordersElement = new XElement("Orders");

            using (var reader = select.ExecuteReader())
            {
                while (reader.Read())
                {
                    var order = new XElement("Order",
                        new XElement("Id", reader.GetInt32(0)),
                        new XElement("OrderNumber", reader.GetString(1)),
                        new XElement("Amount", reader.GetDouble(2)),
                        new XElement("CreatedAt", reader.GetString(3))
                    );
                    ordersElement.Add(order);
                }
            }

            var doc = new XDocument(ordersElement);
            doc.Save(xmlFile);

            Log($"XML сохранён в файл: {xmlFile}");
        }
        catch (Exception ex)
        {
            Log($"Ошибка при обновлении XML: {ex.Message}", isError: true);
            throw;
        }
    }

    private static async Task SendXmlToSoap(string xmlFile, string url, string soapAction)
    {
        try
        {
            string xmlContent = XDocument.Load(xmlFile).ToString(SaveOptions.DisableFormatting);

            // Формируем SOAP-обёртку
            string soapEnvelope = $@"
                <soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:ord=""http://tempuri.org/"">
                   <soapenv:Header/>
                   <soapenv:Body>
                      <ord:SendOrders>
                         <ord:ordersXml>{System.Security.SecurityElement.Escape(xmlContent)}</ord:ordersXml>
                      </ord:SendOrders>
                   </soapenv:Body>
                </soapenv:Envelope>";

            Log("Отправка SOAP-запроса...");

            var content = new StringContent(soapEnvelope, Encoding.UTF8, "text/xml");
            content.Headers.Add("SOAPAction", soapAction);

            var response = await client.PostAsync(url, content);
            string respBody = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                Log($"SOAP-запрос успешно отправлен. Статус: {response.StatusCode}");
                Log($"Ответ сервера:\n{respBody}");
            }
            else
            {
                Log($"Ошибка при отправке SOAP: {response.StatusCode}\nОтвет:\n{respBody}", isError: true);
            }
        }
        catch (Exception ex)
        {
            Log($"Ошибка при отправке SOAP: {ex.Message}", isError: true);
        }
    }

    private static void Log(string message, bool isError = false)
    {
        string logLine = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [{(isError ? "ERROR" : "INFO ")}] {message}";
        Console.WriteLine(logLine);

        try
        {
            using var writer = new StreamWriter(LogFile, append: true, Encoding.UTF8);
            writer.WriteLine(logLine);
        }
        catch
        {
            // игнорируем, если файл занят
        }
    }
}
